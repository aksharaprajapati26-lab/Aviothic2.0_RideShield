# Aviothic2.0_RideShield
Tic Tac Toe project : A simple yet strategic game built with [tecnology stack],featuring single-player and multiplayer modes,intutive UI,and win/draw tracking
